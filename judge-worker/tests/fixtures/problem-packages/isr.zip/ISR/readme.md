### Problem Info
- Name: ISR
- Contest: stl
- Author(s): David Fu
- Tester(s): David Han
- Source (if applicable): n/a
- Target time complexity: $O(n\log n)$
- Target space complexity: $O(n)$
- Category: pre-class
- Status: active

### Solution Sketch

For each index $i$, calculate the maximum sum of subarrays that end at $i$. This can be reduced to finding the minimum prefix sum and subtract the sum from the prefix sum. This can be done in $O(1)$ but solutions with `set`/`unordered_set` are also correct. 

### Deployment Checklist
- [x] problem statement (writer)
- [x] problem readme (writer)
- [x] jury solution (writer)
- [x] sample inputs (writer)
- [x] random inputs (writer)
- [x] big inputs (writer)
- [x] edge case inputs (writer)
- [x] answer files (writer)
- [x] time limit/memory limit (writer)
- [x] sample WA code (writer)
- [x] sample TLE code (if applicable) (writer)
- [x] sample RE code (if applicable) (writer)
- [x] input validator (tester)
- [x] correct solution (in Python if possible) (tester)
- [x] deployment (tester)
- [x] check solution verdicts and limits (tester)