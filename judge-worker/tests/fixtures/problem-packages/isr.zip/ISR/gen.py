from random import randint

for i in range(16, 17):
    with open(f"problem/data/secret/{i}.in", 'w') as f:
        n = int(1e5)
        f.write(str(n) + '\n')

        for i in range(n):
            f.write(str(randint(-1e5, 1e5)) + ' ')