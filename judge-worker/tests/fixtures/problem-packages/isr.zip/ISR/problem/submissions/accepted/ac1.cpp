#include <bits/stdc++.h>
using namespace std;
long long n,i,a[100005],s[100005],smin[100005],ans;

int main() {
	cin >> n;
	for (i=1;i<=n;i++) {
		cin >> a[i];
	}
	for (i=1;i<=n;i++) {
		s[i]=s[i-1]+a[i];
	}
	for (i=1;i<=n;i++) {
		smin[i]=min(s[i],smin[i-1]);
	}
	for (i=1;i<=n;i++) {
		ans=max(ans,s[i]-smin[i-1]);
	}
	cout << ans << endl;
}
