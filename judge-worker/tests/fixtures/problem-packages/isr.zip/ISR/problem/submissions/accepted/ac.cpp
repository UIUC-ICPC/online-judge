#include <bits/stdc++.h>
using namespace std;

const int maxn = 111111;
typedef long long ll;

int n, a[maxn];

int main() {
    scanf("%d", &n);

    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);

    set<ll> s;
    s.insert(0);

    ll ans = 0, sum = 0;

    for (int i = 1; i <= n; i++) {
        sum += a[i];
        ans = max(ans, sum - *s.begin());

        s.insert(sum);
    }   

    printf("%lld\n", ans);
}