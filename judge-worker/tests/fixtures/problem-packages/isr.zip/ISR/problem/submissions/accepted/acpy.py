n = int(input())
a = list(map(int, input().split()))
s = [0]
smin = [0]
ans = 0

for i in range(1, n + 1):
    s.append(s[i-1]+a[i - 1])

for i in range(1, n + 1):
    smin.append(min(s[i], smin[i - 1]))

for i in range(1, n + 1):
    ans = max(ans, s[i] - smin[i - 1])

print(ans)