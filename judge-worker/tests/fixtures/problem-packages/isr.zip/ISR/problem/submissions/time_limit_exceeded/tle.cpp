#include <bits/stdc++.h>
using namespace std;

const int maxn = 111111;
typedef long long ll;

int n, a[maxn];

int main() {
    scanf("%d", &n);

    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);

    ll ans = 0;

    for (int i = 1; i <= n; i++) {
        ll sum = 0;

        for (int j = i; j <= n; j++) {
            ans = max(ans, sum += a[j]);
        }
    }

    printf("%lld\n", ans);
}