#include <bits/stdc++.h>
using namespace std;
long long n,a[100005],s,ans;

int main() {
    cin >> n;
    for (int i=1;i<=n;i++) {
        cin >> a[i];
    }
    for (int i=1;i<=n;i++) {
        if (a[i]>0) {
            s += a[i];
        }
        else {
            s = 0;
            ans = max(ans, s);
        }
    }
    cout << ans << endl;
}