#include "testlib.h"

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);

    int n = inf.readInt(1, 100'000, "n");
    inf.readEoln();
    inf.readInts(n, -100'000, 100'000, "a");
    inf.readEoln();
    inf.readEof();

    exit(OK_EXIT_CODE);
}