### Problem Info
- Name: Beautiful Sum
- Contest: stl
- Author(s): Enya Chen
- Tester(s):
- Source (if applicable):
- Target time complexity: O(N\log N)
- Target space complexity: O(N)
- Category: pre-class
- Status: active

### Solution Sketch

Search for the maximum $m_1$ and second maximum $m_2$ as well as the minimum $m_3$ and second minimum $m_4$ for each array. We can do this easily by sorting the array. The solution is $m_1 + m_2 - m_3 - m_4$. We can guarentee a proper subsegment exists such that it's values are $m_1 + m_2 - m_3 - m_4$.

### Deployment Checklist
- [x] problem statement (writer)
- [x] problem readme (writer)
- [x] jury solution (writer)
- [x] sample inputs (writer)
- [x] random inputs (writer)
- [x] big inputs (writer)
- [x] edge case inputs (writer)
- [x] answer files (writer)
- [x] time limit/memory limit (writer)
- [x] sample WA code (writer)
- [x] sample TLE code (if applicable) (writer)
- [x] sample RE code (if applicable) (writer)
- [x] input validator (tester)
- [x] correct solution (in Python if possible) (tester)
- [x] deployment (tester)
- [x] check solution verdicts and limits (tester)
