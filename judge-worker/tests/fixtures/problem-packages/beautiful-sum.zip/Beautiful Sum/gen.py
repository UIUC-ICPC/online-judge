from pathlib import Path
from random import randint, sample, shuffle


MAX_T = 1000
MAX_SUM_N = 100_000
MAX_A = 1_000_000_000
SECRET_DIR = Path("problem/data/secret")


def write_case(f, arr):
    f.write(f"{len(arr)}\n")
    f.write(" ".join(map(str, arr)) + "\n")


def write_file(file_id, cases):
    assert 1 <= len(cases) <= MAX_T
    assert sum(len(case) for case in cases) <= MAX_SUM_N

    with open(SECRET_DIR / f"secret_{file_id}.in", "w") as f:
        f.write(f"{len(cases)}\n")
        for case in cases:
            assert 4 <= len(case) <= MAX_SUM_N
            assert all(1 <= x <= MAX_A for x in case)
            write_case(f, case)


def random_case(n, lo=1, hi=MAX_A):
    return [randint(lo, hi) for _ in range(n)]


def many_small_cases(total_n=MAX_SUM_N):
    cases = []
    remaining = total_n
    while remaining >= 4 and len(cases) < MAX_T:
        n = randint(4, min(100, remaining))
        cases.append(random_case(n))
        remaining -= n
    return cases


SECRET_DIR.mkdir(parents=True, exist_ok=True)

# Small random cases.
for file_id in range(0, 8):
    cases = [random_case(randint(4, 10), 1, 10) for _ in range(randint(1, 10))]
    write_file(file_id, cases)

# Targeted edge cases.
edge_cases = [
    [1, 1, 1, 1],
    [MAX_A, MAX_A, MAX_A, MAX_A],
    [1, 1, MAX_A, MAX_A],
    [1, MAX_A, 1, MAX_A],
    [1, 2, 3, 4],
    [4, 3, 2, 1],
    [5, 5, 5, 6, 6],
    [1, 2, 2, 2, 2, MAX_A],
    [1, 1, 1, MAX_A, MAX_A, MAX_A],
    list(range(1, 101)),
    list(range(100, 0, -1)),
]
write_file(8, edge_cases)

# A maximum-size single case.
large_case = random_case(MAX_SUM_N)
write_file(9, [large_case])

# Many cases while respecting sum(n) <= 100000.
for file_id in range(10, 20):
    write_file(file_id, many_small_cases())

# Medium and large mixed cases.
for file_id in range(20, 30):
    cases = []
    remaining = MAX_SUM_N
    while remaining >= 4 and len(cases) < MAX_T:
        n = randint(4, min(10_000, remaining))
        cases.append(random_case(n))
        remaining -= n
    write_file(file_id, cases)

# Structured large cases that catch solutions relying on input order or uniqueness.
for file_id in range(30, 35):
    n = MAX_SUM_N
    values = sample(range(1, MAX_A + 1), n)
    if file_id % 3 == 0:
        values.sort()
    elif file_id % 3 == 1:
        values.sort(reverse=True)
    else:
        shuffle(values)
    write_file(file_id, [values])
