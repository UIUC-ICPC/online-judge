#include "testlib.h"

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);

    int t = inf.readInt(1, 1000, "t");
    inf.readEoln();

    for (int testCase = 1; testCase <= t; ++testCase) {
        int n = inf.readInt(4, 100'000, "n");
        inf.readEoln();

        inf.readInts(n, 1, 1'000'000'000, "a");
        inf.readEoln();
    }

    inf.readEof();
    exit(OK_EXIT_CODE);
}
