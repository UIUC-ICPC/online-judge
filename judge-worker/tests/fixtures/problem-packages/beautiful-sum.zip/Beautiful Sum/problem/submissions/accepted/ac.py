t = int(input())
for _ in range(t):
    n = int(input())
    nums = map(int, input().split())
    nums = sorted(nums)
    print(nums[-1] + nums[-2] - nums[0] - nums[1])
