#pragma optimize("O3")

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ll> vll;
typedef vector<vll> vvll;

 
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        vi v(n);
        for (int i = 0; i < n; i++) {
            cin >> v[i];
        }
        
        int res = 0;
        for (int l = 0; l < n - 1; l++) {
            for (int r = l + 1; r < n; r++) {
                
                int m1 = 0;
                int m2 = 0;
                int m3 = INT_MAX;
                int m4 = INT_MAX;
                for (int i = 0; i < l; i++) {
                    m1 = max(m1, v[i]);
                }
                for (int i = r + 1; i < n; i++) {
                    m2 = max(m2, v[i]);
                }
                for (int i = l; i <= r; i++) {
                    m3 = min(m3, v[i]);
                }
                for (int i = l; i <= r; i++) {
                    m4 = min(m4, v[i]);
                }
                
                res = max(res, m1 + m2 - m3 - m4);
            }
        }
        cout << res << endl;

    }
}